REPFORMED — Palette 09 social assets — 2026-10-27
Generated original raster artwork using approved angular R reference. Metallic lighting creates natural tonal variations around charcoal #181818 / gold #C7A45C / ivory #FAF5EA / steel #8C939D.

Profile: 1024x1024 PNG. Shared asset for YouTube, TikTok, Instagram, Facebook and X. Logo kept inside circular crop; no small text.
X: 1500x500 PNG. Main content center/right; lower-left kept decorative for avatar overlay.
YouTube: 2560x1440 JPEG, under 1 MB. Revised central compact lockup; key content approximately x750..1870 y605..795, within centered1546x423 safe region. Outer art is decorative.
Facebook: 1640x624 PNG. Main content centered and lower-left decorative. Actual native/mobile crop must be previewed in uploader before saving; page layouts vary.

Inspected generated compositions for spelling, logo consistency and four-color use; exact exported dimensions verified. Native account previews and publication NOT performed. No social account changes.
Primary reference: https://help.x.com/en/managing-your-account/how-to-customize-your-profile confirms 1500x500 header and400x400 profile recommendation. Profile1024 master can be downsampled by platform.
YouTube official https://support.google.com/youtube/answer/10456525 fetch timed out during check; live uploader QA remains required. Facebook current official source not independently fetched.
Imagegen source masters remain in generated_images. These exports use size-only resampling; no generative repaint after final visual approval.
